# Glance 2 bundle

This zip is everything needed to put the Glance website pull request into the
(empty) repository `sarang-cmd/glance-2` and open the PR. It exists because
the GitHub credential inside the build sandbox could read glance-2 but was
not allowed to write to it, so the pushes could not happen there. Running the
script on your own machine, with your own git and gh credentials, does the
whole job.

## What is inside

- `setup-glance-2.bat` - Windows script that does everything (see below).
- `pr-body.md` - the pull request description (identical to
  `sarang-cmd/glance` PR #2).
- The rest of the folder is a plain copy of the `arena/366a3971-glance`
  branch of `sarang-cmd/glance` at commit `dbd9f21` (the website under
  `web/`, plus README, PRD, assets and LICENSE). For browsing only; the
  script does not use this copy for the push.

## Prerequisites

- Windows with Git for Windows: https://git-scm.com/
- GitHub CLI: `winget install --id GitHub.cli`
- `gh auth login` completed, with an account that can push to
  `sarang-cmd/glance-2` (your `sarang-cmd` account can; the sandbox token
  could not).

## How to run

Double-click `setup-glance-2.bat`, or from a terminal in this folder:

```bat
setup-glance-2.bat
```

## What the script does

1. Checks that `git` and `gh` exist and that `gh` is authenticated.
2. Clones the public `sarang-cmd/glance` into a fresh temp folder.
3. Moves local `main` back to the base commit `b0a5779` (the commit the
   website branch was cut from).
4. Creates/checks out `arena/366a3971-glance` from the remote branch.
5. Repoints `origin` to `https://github.com/sarang-cmd/glance-2.git` and
   pushes both branches (`main` first, then the branch).
6. Opens the PR against `main` with `pr-body.md` as the body.

It never force-pushes and never merges anything. If a PR already exists for
the branch, `gh` says so and the branches are already up to date; that is
fine. The temp clone is left in `%TEMP%` for inspection and can be deleted.

## Manual fallback

```bat
git clone https://github.com/sarang-cmd/glance work && cd work
git checkout -B arena/366a3971-glance origin/arena/366a3971-glance
git branch -f main b0a57799662eb18e86393152ef1143ecf61f9edc
git remote set-url origin https://github.com/sarang-cmd/glance-2.git
git push -u origin main arena/366a3971-glance
gh pr create -R sarang-cmd/glance-2 --base main --head arena/366a3971-glance ^
  --title "Marketing and docs website for Glance (web/)" --body-file ..\pr-body.md
```

## Honest status (as of 2026-11-06)

- The Vercel project `glance-2-win` is already created and production was
  deployed from the `arena/366a3971-glance` branch; the site is live at
  https://glance-2-win.vercel.app (built from the glance repo; redeploy from
  glance-2 once these branches exist if you want the deployment built from
  glance-2 itself).
- No `DATABASE_URL` / `RESEND_API_KEY` / `RESEND_FROM` is set, so the release
  list shows its designed "not available yet" state. Set those in the Vercel
  project settings to enable double opt-in signup (Neon + Resend).
- The PR does not merge itself and must not be merged until you have reviewed
  it; legal pages remain drafts marked DRAFT FOR REVIEW.
- This bundle carries no credentials and no secrets.
