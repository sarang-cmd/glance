@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Glance 2 - create the pull request

echo.
echo  Glance 2: push the website branch to sarang-cmd/glance-2 and open a PR
echo  =====================================================================
echo.
echo  This script clones the PUBLIC glance repository, recreates the two
echo  branches, pushes them to sarang-cmd/glance-2, and opens the pull
echo  request. It uses YOUR local git and gh credentials.
echo.

where git >nul 2>&1 || goto :nogit
where gh  >nul 2>&1 || goto :nogh

echo Checking GitHub authentication...
gh auth status >nul 2>&1 || goto :noauth
echo GitHub CLI is authenticated.
echo.

set "WORK=%TEMP%\glance-2-setup-%RANDOM%%RANDOM%"

echo Step 1/5  Cloning sarang-cmd/glance (public)...
git clone -q https://github.com/sarang-cmd/glance "%WORK%" || goto :fail
cd /d "%WORK%"

echo Step 2/5  Checking out arena/366a3971-glance...
git checkout -q -B arena/366a3971-glance origin/arena/366a3971-glance || goto :fail

echo Step 3/5  Pointing main at the base commit b0a5779...
git branch -f main b0a57799662eb18e86393152ef1143ecf61f9edc || goto :fail

echo Step 4/5  Repointing origin to sarang-cmd/glance-2...
git remote set-url origin https://github.com/sarang-cmd/glance-2.git || goto :fail

echo Step 5/5  Pushing main and arena/366a3971-glance...
git push -u origin main arena/366a3971-glance || goto :fail
echo.

echo Opening the pull request...
gh pr create -R sarang-cmd/glance-2 --base main --head arena/366a3971-glance --title "Marketing and docs website for Glance (web/)" --body-file "%~dp0pr-body.md"
if errorlevel 1 (
  echo.
  echo The push succeeded but the PR could not be created automatically.
  echo If it says a pull request already exists, that is expected:
  echo   https://github.com/sarang-cmd/glance-2/pulls
  goto :done
)

:done
echo.
echo Done. Check https://github.com/sarang-cmd/glance-2/pulls
echo The temporary clone was left at:
echo   %WORK%
echo You can delete that folder whenever you like.
goto :end

:nogit
echo ERROR: git was not found on PATH.
echo Install Git for Windows from https://git-scm.com/ then run this again.
goto :end

:nogh
echo ERROR: GitHub CLI ^(gh^) was not found on PATH.
echo Install it with:  winget install --id GitHub.cli
echo Then run:  gh auth login
goto :end

:noauth
echo ERROR: GitHub CLI is not authenticated.
echo Run:  gh auth login
echo and make sure the account it uses can push to sarang-cmd/glance-2.
goto :end

:fail
echo.
echo A STEP FAILED. Nothing was deleted anywhere.
echo The temporary clone is at:
echo   %WORK%
echo Fix the problem and rerun, or use the manual commands in README-GLANCE-2.md.

:end
endlocal
pause
