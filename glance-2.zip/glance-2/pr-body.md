## What this is

The complete marketing and documentation website for Glance, the ad-free lock screen widgets for Windows 11. Everything lives in `web/` (Next.js App Router, TypeScript). Existing repo files (README, PRD, assets, LICENSE) are untouched except for web ignore rules in the root `.gitignore`.

Status of the product it represents: **planning, nothing released.** The site carries no download button, no release date, no invented stats, logos or testimonials. All copy comes from the README and PRD; every simulated visual is labeled ("Interactive demo with sample data" or "Illustration with sample data"). The one use of `assets/hero.png` is a single captioned "Concept render" figure.

## Pages

`/` (hero, widget roster, live demos, release-list CTA), `/widgets` (one section per family: Battery+, habit rings, consistency graph, study bridge, Calendar, Tasks, System health, GitHub streak, Today card, weekly recap), `/how-it-works` (MSIX, Widgets board, Adaptive Cards, background collector, SQLite), `/roadmap` (M0 to M6 with honest status: all planned, M0 first up), `/get-started` (honest "not released yet", GitHub star, release list), `/faq` (Radix accordion, 10 answers, FAQPage JSON-LD), `/privacy`, `/terms`, `/imprint` (drafts with DRAFT FOR REVIEW placeholders, no invented legal details), custom 404, and release-list confirm/unsubscribe/thank-you states.

## Release list

Double opt-in (32-byte single-use tokens), Neon Postgres (parameterized queries, schema in `web/db/schema.sql`), Resend plain branded emails (HTML and text, no tracking pixels, one-click unsubscribe in every footer), honeypot, origin check, in-memory sliding-window rate limit (documented as per-instance; paired with a 300/day global email backstop), failure-closed 503/502 states, and the endpoint never reveals list membership. The site sets zero cookies; the consent choice lives in localStorage.

## Security and SEO

CSP, HSTS, nosniff, X-Frame-Options DENY, Referrer-Policy, Permissions-Policy; source maps off; no secrets in the repo (`.env.example` committed, `.env*.local` gitignored and verified). Unique title, description and canonical per page, one H1 each, per-page OG images, sitemap.xml, robots.txt that explicitly allows AI crawlers, llms.txt, BreadcrumbList/SoftwareApplication/FAQPage JSON-LD, full favicon set and web manifest, dark mode with persistence, skip link, focus-visible rings, reduced-motion respected.

## Verification done

Production build clean (13 static routes); `tsc` and lint clean; 9/9 tests pass (`npm test`, flow tests against in-memory Postgres running the real schema: signup, token rotation, confirm, welcome, unsubscribe, rate limiter, email templates); HTTP smoke tests on the production build (all pages 200, one H1 each, all internal links resolve, security headers verified via curl, API 400/403/415/503 paths verified); 24/24 light and dark token pairs pass WCAG AA by computed contrast.

## Known gaps (details in web/CHANGES.md, work items in web/TASKS.md)

- No browser in the build environment: no visual pass at 390/1440 px, no Lighthouse score claimed, dark theme unverified by eye.
- No live Neon/Resend credentials: the email round-trip is tested at logic and template level, not over real SMTP/HTTP.
- Legal pages are drafts; the imprint postal address needs the owner and their advisor.
- CSP keeps `'unsafe-inline'` for scripts (Next.js bootstrap); rate limiting is per serverless instance.

## Docs

Linear-importable remaining work: `web/TASKS.md`. Honest test report and the extracted anti-pattern checklist: `web/CHANGES.md`. Domain, env and DNS notes for Vercel, Neon, Resend and Cloudflare: `web/README.md`.

